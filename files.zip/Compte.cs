namespace GestionCRM;

/// <summary>Compte client : une entreprise suivie dans le CRM.</summary>
public class Compte
{
    public int Id { get; set; }
    public string Nom { get; set; }
    public string Secteur { get; set; }
    public string SiteWeb { get; set; }
    public string Telephone { get; set; }
    public string Ville { get; set; }

    public List<Contact> Contacts { get; } = new();
    public List<Opportunite> Opportunites { get; } = new();

    public Compte(int id, string nom, string secteur, string siteWeb, string telephone, string ville)
    {
        Id = id;
        Nom = nom;
        Secteur = secteur;
        SiteWeb = siteWeb;
        Telephone = telephone;
        Ville = ville;
    }

    public void AjouterContact(Contact contact)
    {
        contact.Compte = this;
        Contacts.Add(contact);
    }

    public void AjouterOpportunite(Opportunite opportunite)
    {
        opportunite.Compte = this;
        Opportunites.Add(opportunite);
    }

    /// <summary>Chiffre d'affaires = somme des opportunités gagnées (historique des ventes).</summary>
    public decimal CalculerChiffreAffaires()
    {
        return Opportunites
            .Where(o => o.Etape == Etape.Gagnee)
            .Sum(o => o.Montant);
    }

    public override string ToString() => $"{Nom} - {Ville}";
}
