namespace GestionCRM;

/// <summary>Utilisateur du CRM (admin, commercial ou lecteur).</summary>
public class Utilisateur
{
    public int Id { get; set; }
    public string Nom { get; set; }
    public string Email { get; set; }
    // Mot de passe en clair uniquement pour ce projet de classe.
    // Dans une vraie application, on stocke un hash.
    public string MotDePasse { get; set; }
    public Role Role { get; set; }

    /// <summary>Opportunités dont l'utilisateur est responsable.</summary>
    public List<Opportunite> Opportunites { get; } = new();

    public Utilisateur(int id, string nom, string email, string motDePasse, Role role)
    {
        Id = id;
        Nom = nom;
        Email = email;
        MotDePasse = motDePasse;
        Role = role;
    }

    public bool SeConnecter(string email, string motDePasse)
    {
        return Email.Equals(email, StringComparison.OrdinalIgnoreCase)
               && MotDePasse == motDePasse;
    }

    /// <summary>Admin et commercial peuvent modifier les données, pas le lecteur.</summary>
    public bool PeutModifier() => Role != Role.Lecteur;

    public bool PeutGererUtilisateurs() => Role == Role.Admin;

    public override string ToString() => $"{Nom} ({Role})";
}
