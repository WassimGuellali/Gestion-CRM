namespace GestionCRM;

/// <summary>Rôle d'un utilisateur du CRM.</summary>
public enum Role
{
    Admin,       // accès complet
    Commercial,  // gestion des comptes, contacts, opportunités et activités
    Lecteur      // lecture seule
}

/// <summary>Étape d'une opportunité dans le pipeline de vente.</summary>
public enum Etape
{
    Prospection,
    Qualification,
    Proposition,
    Negociation,
    Gagnee,
    Perdue
}

/// <summary>Type d'une activité commerciale.</summary>
public enum TypeActivite
{
    Appel,
    Email,
    Reunion,
    Tache
}
