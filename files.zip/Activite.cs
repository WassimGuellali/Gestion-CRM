namespace GestionCRM;

/// <summary>Activité commerciale : appel, email, réunion ou tâche.</summary>
public class Activite
{
    public int Id { get; set; }
    public string Titre { get; set; }
    public string Description { get; set; }
    public TypeActivite Type { get; set; }
    public DateTime DateHeure { get; set; }

    public Opportunite? Opportunite { get; set; }
    public Contact? Contact { get; set; }

    public Activite(int id, string titre, string description, TypeActivite type, DateTime dateHeure)
    {
        Id = id;
        Titre = titre;
        Description = description;
        Type = type;
        DateHeure = dateHeure;
    }

    public override string ToString() => $"[{Type}] {Titre} - {DateHeure:dd/MM/yyyy HH:mm}";
}
