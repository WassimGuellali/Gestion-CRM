namespace GestionCRM;

/// <summary>Personne à contacter chez un compte client.</summary>
public class Contact
{
    public int Id { get; set; }
    public string Nom { get; set; }
    public string Prenom { get; set; }
    public string Email { get; set; }
    public string Telephone { get; set; }
    public string Poste { get; set; }

    public Compte? Compte { get; set; }
    public List<Activite> Activites { get; } = new();

    public Contact(int id, string nom, string prenom, string email, string telephone, string poste)
    {
        Id = id;
        Nom = nom;
        Prenom = prenom;
        Email = email;
        Telephone = telephone;
        Poste = poste;
    }

    public string NomComplet => $"{Prenom} {Nom}";

    public void AjouterActivite(Activite activite)
    {
        activite.Contact = this;
        Activites.Add(activite);
    }

    public override string ToString() => $"{NomComplet} <{Email}>";
}
