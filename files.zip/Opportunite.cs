namespace GestionCRM;

/// <summary>Opportunité de vente suivie dans le pipeline.</summary>
public class Opportunite
{
    private int _probabilite;

    public int Id { get; set; }
    public string Titre { get; set; }
    public decimal Montant { get; set; }
    public DateTime DateCloture { get; set; }
    public Etape Etape { get; set; }

    /// <summary>Probabilité de réussite en pourcentage (0 à 100).</summary>
    public int Probabilite
    {
        get => _probabilite;
        set
        {
            if (value < 0 || value > 100)
                throw new ArgumentOutOfRangeException(nameof(value), "La probabilité doit être entre 0 et 100.");
            _probabilite = value;
        }
    }

    public Compte? Compte { get; set; }
    public Utilisateur? Responsable { get; set; }
    public List<Activite> Activites { get; } = new();

    public Opportunite(int id, string titre, decimal montant, int probabilite,
                       DateTime dateCloture, Etape etape = Etape.Prospection)
    {
        Id = id;
        Titre = titre;
        Montant = montant;
        Probabilite = probabilite;
        DateCloture = dateCloture;
        Etape = etape;
    }

    public void AssignerResponsable(Utilisateur utilisateur)
    {
        Responsable = utilisateur;
        utilisateur.Opportunites.Add(this);
    }

    public void AjouterActivite(Activite activite)
    {
        activite.Opportunite = this;
        Activites.Add(activite);
    }

    public void ChangerEtape(Etape nouvelleEtape)
    {
        Etape = nouvelleEtape;
        if (nouvelleEtape == Etape.Gagnee) Probabilite = 100;
        if (nouvelleEtape == Etape.Perdue) Probabilite = 0;
    }

    /// <summary>Montant pondéré par la probabilité de réussite.</summary>
    public decimal CalculerMontantPondere() => Montant * Probabilite / 100m;

    public override string ToString() => $"{Titre} - {Montant} TND ({Etape})";
}
