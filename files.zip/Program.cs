using GestionCRM;

Console.OutputEncoding = System.Text.Encoding.UTF8;

// Utilisateurs
var admin = new Utilisateur(1, "Admin", "admin@crm.tn", "admin123", Role.Admin);
var sarah = new Utilisateur(2, "Sarah Abdelli", "sarah@crm.tn", "sarah123", Role.Commercial);

// Compte et contacts
var techCorp = new Compte(1, "TechCorp Tunisia", "Technologie", "www.techcorp.tn", "+216 71 123 456", "Tunis");
var mohamed = new Contact(1, "Ben Ali", "Mohamed", "mohamed.benali@techcorp.tn", "+216 20 111 222", "Directeur technique");
var fatma = new Contact(2, "Trabelsi", "Fatma", "fatma.trabelsi@techcorp.tn", "+216 20 333 444", "Responsable achats");
techCorp.AjouterContact(mohamed);
techCorp.AjouterContact(fatma);

// Opportunités
var siteWeb = new Opportunite(1, "Développement site e-commerce", 12000m, 100, new DateTime(2026, 3, 30), Etape.Gagnee);
var appMobile = new Opportunite(2, "Application mobile iOS/Android", 35000m, 40, new DateTime(2026, 6, 30), Etape.Qualification);
var formation = new Opportunite(3, "Formation développement web", 8000m, 20, new DateTime(2026, 5, 1));

foreach (var opp in new[] { siteWeb, appMobile, formation })
{
    techCorp.AjouterOpportunite(opp);
    opp.AssignerResponsable(sarah);
}

// Activités
var appel = new Activite(1, "Discussion sur le projet e-commerce",
    "Appel pour discuter des spécifications techniques", TypeActivite.Appel, new DateTime(2026, 3, 24, 10, 0, 0));
siteWeb.AjouterActivite(appel);
mohamed.AjouterActivite(appel);

// Affichage
Console.WriteLine($"Compte : {techCorp}");
Console.WriteLine($"Contacts : {techCorp.Contacts.Count}");
foreach (var c in techCorp.Contacts) Console.WriteLine($"  - {c}");

Console.WriteLine("\nOpportunités :");
foreach (var o in techCorp.Opportunites)
    Console.WriteLine($"  - {o} | pondéré : {o.CalculerMontantPondere()} TND | responsable : {o.Responsable}");

Console.WriteLine($"\nChiffre d'affaires (ventes gagnées) : {techCorp.CalculerChiffreAffaires()} TND");

formation.ChangerEtape(Etape.Proposition);
Console.WriteLine($"\nÉtape de « {formation.Titre} » : {formation.Etape}");

Console.WriteLine($"\nActivité : {appel}");
Console.WriteLine($"Connexion admin OK : {admin.SeConnecter("admin@crm.tn", "admin123")}");
Console.WriteLine($"Sarah peut gérer les utilisateurs : {sarah.PeutGererUtilisateurs()}");
